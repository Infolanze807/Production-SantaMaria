import React, { useState, useEffect } from 'react';
import axios from 'axios';

function GetCompany() {
    const [companyData, setCompanyData] = useState([]);
    const [selectedCompany, setSelectedCompany] = useState(null);

    // const base64EncodedIdObject = Buffer.from(JSON.stringify({
    //     "iv": "5708c1d14c0ee97ae19bbbd4f6c",
    //     "encryptedData": "17c4c0fe0f9687bf6e66c0ee3ee63b86"
    // })).toString('base64');
    
    // console.log('base64EncodedIdObject', base64EncodedIdObject);

//   const firstCompanyId = response.data.data.data[0].id;
//   console.log("encryptedData:", firstCompanyId.encryptedData);
//   console.log("iv:", firstCompanyId.iv);

    useEffect(() => {
        const fetchCompanyData = async () => {
            try {
                const token = localStorage.getItem('token');
                if (!token) {
                    throw new Error('No token found. Please login again.');
                }

                const response = await axios.get('http://ec2-16-170-165-104.eu-north-1.compute.amazonaws.com:5000/api/admin/company', {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                setCompanyData(response.data.data.data);
                
            } catch (error) {
                console.error('Error fetching company data:', error);
                setError('Error fetching company data. Please try again.');
            }
        };

        fetchCompanyData();
    }, []);

    const handleViewClick = (company) => {
        setSelectedCompany(company);
    };

    const handleCloseClick = () => {
        setSelectedCompany(null);
    };

    const handleDeleteClick = async (companyId) => {
        try {
            const token = localStorage.getItem('token');
            if (!token) {
                throw new Error('No token found. Please login again.');
            }
            
            await axios.delete(`http://ec2-16-170-165-104.eu-north-1.compute.amazonaws.com:5000/api/admin/company/${companyId}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            
        } catch (error) {
            console.error('Error deleting company:', error);   
        }
    }

    return (
        <div>
            {companyData.map(company => (
                <div key={company.id.encryptedData} className="grid lg:grid-cols-6 grid-cols-1 items-center border rounded-lg p-5 bg-[--main-color] mb-5">
                    <div className='col-span-2 relative'>
                        <div className='pt-11 lg:w-72'>
                            <img className='-z-10 w-full object-cover rounded-lg' src={company.cover_image} alt="" />
                        </div>
                        <div className=''>
                            <img className='absolute border-4 bg-white w-24 h-24 rounded-full object-cover left-6 top-0' src={company.profile_image} alt="" />
                        </div>
                    </div>
                    <div className='col-span-3 text-gray-900 font-semibold text-sm leading-relaxed pt-5 lg:pt-0'>
                        <div>Name: &nbsp;<span className='font-normal'>{company.name}</span></div>
                        <div>Bio: &nbsp;<span className='font-normal'>{company.bio}</span></div>
                        <div>Number: &nbsp;<span className='font-normal'>{company.contact_no}</span></div>
                        <div>Instagram URL: &nbsp;<span className='font-normal'>{company.instagram_url}</span></div>
                        <div>Link: &nbsp;<span className='font-normal'>{company.location}</span></div>
                    </div>
                    <div className='lg:flex lg:flex-col mx-auto gap-2 pt-4 lg:pt-0'>
                        <button className="bg-green-500 px-8 w-max p-2 text-sm rounded-full text-white lg:me-5 lg:mb-0 mb-3" onClick={() => handleViewClick(company)}>View</button>
                        <button className="bg-red-500 px-7 p-2 w-max text-sm rounded-full text-white" onClick={() => handleDeleteClick()}>Delete</button>
                    </div>
                </div>
            ))}
            {selectedCompany && (
                <div className="fixed p-3 inset-0 flex justify-center items-center bg-black bg-opacity-50 z-50 overflow-y-auto">
                    <div className="bg-white w-[600px] max-w-2xl p-6 rounded-lg">
                        <h2 className="text-2xl font-bold mb-4">Update Company</h2>
                        <form className="max-w-xl mx-auto">
                            <div className="mb-4">
                                <label htmlFor="text" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Company Name</label>
                                <input value={selectedCompany.name} type="text" id="text" className="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Company Name..." required />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="text" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Company Bio</label>
                                <textarea value={selectedCompany.bio} placeholder='Company Bio...' type="text" id="text" className="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="tel" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Contact Number</label>
                                <input value={selectedCompany.contact_no} placeholder='Number...' type="tel" id="text" className="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required />
                            </div>
                            <div className='mb-4'>
                                <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white" htmlFor="user_avatar">Profile Image</label>
                                <input className="block w-full p-2 text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-white dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400" aria-describedby="user_avatar_help" id="user_avatar" type="file" />
                            </div>
                            <div className='mb-4'>
                                <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white" htmlFor="user_avatar">Cover Image</label>
                                <input className="block w-full p-2 text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-white dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400" aria-describedby="user_avatar_help" id="user_avatar" type="file" />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="text" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Instagram URL</label>
                                <input value={selectedCompany.instagram_url} type="text" id="text" className="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Instagram Handle..." required />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="text" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Location Link</label>
                                <input value={selectedCompany.location} type="text" id="text" className="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Link..." required />
                            </div>
                            <div className="flex justify-between mt-4">
                                <button type='submit' className="bg-green-500 text-white px-4 py-2 rounded mr-4">Update</button>
                                <button className="bg-red-500 text-white px-4 py-2 rounded" onClick={handleCloseClick}>Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}

export default GetCompany;
