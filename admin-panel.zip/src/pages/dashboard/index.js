export * from "@/pages/dashboard/Home";
export * from "@/pages/dashboard/Events";
export * from "@/pages/dashboard/Company";
export * from "@/pages/dashboard/Supplier";
export * from "@/pages/dashboard/Banner";
export * from "@/pages/dashboard/Component";
export * from "@/pages/dashboard/Discount";
export * from "@/pages/dashboard/Emergency";
